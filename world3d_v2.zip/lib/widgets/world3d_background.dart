import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'sunny_world_background.dart';

/// کلید بازگشت: false = ظاهر قبلی (آسمان و تپه‌های تخت)، true = دنیای سه‌بعدی.
const bool kWorld3D = true;

/// بر پایهٔ [kWorld3D] یکی از دو پس‌زمینه را نشان می‌دهد.
class WorldBackground extends StatelessWidget {
  final Widget child;
  const WorldBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) =>
      kWorld3D ? World3DBackground(child: child) : SunnyWorldBackground(child: child);
}

/// دنیای سه‌بعدی: لایه‌های عمق‌دار که با حرکت ماوس یا انگشت جابه‌جا می‌شوند.
class World3DBackground extends StatefulWidget {
  final Widget child;
  const World3DBackground({super.key, required this.child});

  @override
  State<World3DBackground> createState() => _World3DBackgroundState();
}

class _World3DBackgroundState extends State<World3DBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 60))..repeat();
  Offset _target = Offset.zero;
  Offset _cur = Offset.zero;

  @override
  void initState() {
    super.initState();
    _c.addListener(() => _cur = Offset.lerp(_cur, _target, 0.07)!);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _move(Offset p, Size s) {
    if (s.width <= 0 || s.height <= 0) return;
    _target = Offset((p.dx / s.width * 2 - 1).clamp(-1.0, 1.0), (p.dy / s.height * 2 - 1).clamp(-1.0, 1.0));
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final size = Size(box.maxWidth, box.maxHeight);
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerHover: (e) => _move(e.localPosition, size),
          onPointerMove: (e) => _move(e.localPosition, size),
          child: Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(
                  child: CustomPaint(painter: _WorldPainter(_c, () => _cur)),
                ),
              ),
              Positioned.fill(child: widget.child),
            ],
          ),
        );
      },
    );
  }
}

class _WorldPainter extends CustomPainter {
  final Animation<double> anim;
  final Offset Function() tilt;
  _WorldPainter(this.anim, this.tilt) : super(repaint: anim);

  static const double _tau = math.pi * 2;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final t = anim.value;
    final tl = tilt();
    final s = (math.min(w, h) / 500).clamp(0.7, 1.4);
    Offset off(double d) => Offset(-tl.dx * d, -tl.dy * d * 0.5);
    void layer(double d, void Function() draw) {
      canvas.save();
      final o = off(d);
      canvas.translate(o.dx, o.dy);
      draw();
      canvas.restore();
    }

    // آسمان
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1E90E8), Color(0xFF59B9F8), Color(0xFF9ADBFF), Color(0xFFD6F0FF), Color(0xFFFFF6DA)],
          stops: [0.0, 0.28, 0.5, 0.7, 0.85],
        ).createShader(rect),
    );

    // خورشید، هاله و پرتوهای نرم
    layer(4, () {
      final sun = Offset(w * 0.82, h * 0.13);
      final r = (math.min(w, h) * 0.075).clamp(26.0, 64.0);
      final rays = Paint()
        ..color = const Color(0x16FFF8E1)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10);
      final reach = math.max(w, h) * 1.3;
      for (var i = 0; i < 5; i++) {
        final a = math.pi * 0.52 + i * 0.2 + math.sin(t * _tau) * 0.03;
        final p = Path()
          ..moveTo(sun.dx, sun.dy)
          ..lineTo(sun.dx + math.cos(a - 0.05) * reach, sun.dy + math.sin(a - 0.05) * reach)
          ..lineTo(sun.dx + math.cos(a + 0.05) * reach, sun.dy + math.sin(a + 0.05) * reach)
          ..close();
        canvas.drawPath(p, rays);
      }
      canvas.drawCircle(
        sun,
        r * 4.5,
        Paint()
          ..shader = const RadialGradient(colors: [Color(0xAAFFF8D0), Color(0x33FFE9A0), Color(0x00FFE9A0)], stops: [0.0, 0.4, 1.0])
              .createShader(Rect.fromCircle(center: sun, radius: r * 4.5)),
      );
      canvas.drawCircle(
        sun,
        r,
        Paint()
          ..shader = const RadialGradient(colors: [Color(0xFFFFFDE7), Color(0xFFFFE57F), Color(0xFFFFCA28)], stops: [0.0, 0.6, 1.0])
              .createShader(Rect.fromCircle(center: sun, radius: r)),
      );
    });

    // رشته‌کوه‌های دور (مه‌آلود)
    layer(6, () {
      _hill(canvas, w, h, 0.64, 0.06, 0.9, 2.3, const Color(0xFFB9DFF2), const Color(0xFFD3EEF8), false);
      _hill(canvas, w, h, 0.69, 0.045, 2.2, 1.6, const Color(0xFFA6D9CC), const Color(0xFFC6E9DE), false);
    });

    // مه نازک افق
    final hazeRect = Rect.fromLTRB(0, h * 0.5, w, h * 0.82);
    canvas.drawRect(
      hazeRect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0x00FFFFFF), Color(0x66FFFFFF)],
        ).createShader(hazeRect),
    );

    // ابرهای نرم
    layer(12, () {
      const clouds = [
        [0.10, 0.10, 1.2, 1.0],
        [0.50, 0.21, 0.9, 2.0],
        [0.80, 0.05, 1.0, 1.0],
      ];
      for (final c in clouds) {
        final x = (((c[0] + t * c[3] * 1.3) % 1.3) - 0.15) * w;
        _cloud(canvas, Offset(x, h * c[1]), c[2] * s * 1.3);
      }
    });

    // تپهٔ میانی با درخت
    layer(20, () {
      _hill(canvas, w, h, 0.77, 0.05, 0.2, 1.0, const Color(0xFF8FD76F), const Color(0xFF63BE4E), true);
      for (final f in const [0.06, 0.2, 0.46, 0.68, 0.92]) {
        final x = f * w;
        _tree(canvas, Offset(x, _hillY(x, w, h, 0.77, 0.05, 0.2, 1.0) + 8 * s), s * (0.85 + (f * 7 % 1) * 0.3));
      }
    });

    // پروانه‌ها
    layer(30, () {
      for (var k = 0; k < 3; k++) {
        final x = w * (0.2 + 0.3 * k + 0.08 * math.sin(t * _tau * 3 + k));
        final y = h * (0.46 + 0.07 * k) + math.sin(t * _tau * 5 + k * 2) * 18 * s;
        _butterfly(canvas, Offset(x, y), s, 0.35 + 0.65 * math.sin(t * _tau * 120 + k).abs(), k);
      }
    });

    // تپهٔ نزدیک با علف و گل
    layer(36, () {
      const base = 0.89, amp = 0.04, ph = 1.4, fq = 1.2;
      _hill(canvas, w, h, base, amp, ph, fq, const Color(0xFF6CCB52), const Color(0xFF47AC3E), true);
      final rnd = math.Random(3);
      for (var i = 0; i < 130; i++) {
        final x = rnd.nextDouble() * w;
        final yy = _hillY(x, w, h, base, amp, ph, fq);
        final y = yy + 6 + rnd.nextDouble() * math.max(8.0, (h - yy) * 0.55);
        final sway = math.sin(t * _tau * 4 + i * 0.7) * 3 * s;
        final len = (10 + rnd.nextDouble() * 10) * s;
        final blade = Path()
          ..moveTo(x, y)
          ..quadraticBezierTo(x + sway * 0.5, y - len * 0.6, x + sway, y - len);
        canvas.drawPath(
          blade,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeWidth = 1.7 * s
            ..color = i.isEven ? const Color(0xCC2F8F36) : const Color(0xCC93E06F),
        );
      }
      const colors = [Color(0xFFFF6FA5), Color(0xFFFFD54F), Colors.white, Color(0xFFFF8A65)];
      for (var i = 0; i < 26; i++) {
        final x = rnd.nextDouble() * w;
        final yy = _hillY(x, w, h, base, amp, ph, fq);
        final y = yy + 14 + rnd.nextDouble() * math.max(8.0, (h - yy) * 0.5);
        final sway = math.sin(t * _tau * 3 + i) * 2 * s;
        _flower(canvas, Offset(x + sway, y), s, colors[i % colors.length]);
      }
    });

    // بوته‌های جلو
    layer(52, () {
      for (final e in const [[0.02, 1.0], [0.97, 1.1]]) {
        final c = Offset(w * e[0], h * 1.0);
        final r = 46 * s * e[1];
        final shader = RadialGradient(
          center: const Alignment(-0.3, -0.5),
          colors: const [Color(0xFF63C24F), Color(0xFF2E8B3A)],
        ).createShader(Rect.fromCircle(center: c, radius: r * 1.6));
        final p = Paint()..shader = shader;
        canvas.drawCircle(c, r, p);
        canvas.drawCircle(c + Offset(-r * 0.7, r * 0.2), r * 0.7, p);
        canvas.drawCircle(c + Offset(r * 0.7, r * 0.2), r * 0.7, p);
      }
    });
  }

  double _hillY(double x, double w, double h, double base, double amp, double phase, double freq) =>
      h * base + math.sin(x / w * _tau * freq + phase) * h * amp;

  void _hill(Canvas canvas, double w, double h, double base, double amp, double phase, double freq, Color top, Color bottom, bool glow) {
    final path = Path()..moveTo(-90, h + 90);
    for (double x = -90; x <= w + 90; x += 10) {
      path.lineTo(x, _hillY(x, w, h, base, amp, phase, freq));
    }
    path
      ..lineTo(w + 90, h + 90)
      ..close();
    final y0 = h * (base - amp);
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [top, bottom])
            .createShader(Rect.fromLTRB(0, y0, w, h)),
    );
    if (glow) {
      final edge = Path();
      for (double x = -90; x <= w + 90; x += 10) {
        final y = _hillY(x, w, h, base, amp, phase, freq);
        x == -90 ? edge.moveTo(x, y) : edge.lineTo(x, y);
      }
      canvas.drawPath(
        edge,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 4
          ..color = const Color(0x44FFFFFF)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
      );
    }
  }

  void _tree(Canvas canvas, Offset b, double s) {
    canvas.drawOval(
      Rect.fromCenter(center: b + Offset(8 * s, 2 * s), width: 46 * s, height: 10 * s),
      Paint()
        ..color = const Color(0x33104020)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
    );
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(b.dx - 4 * s, b.dy - 22 * s, 8 * s, 24 * s), Radius.circular(3 * s)),
      Paint()..color = const Color(0xFF7B5A3C),
    );
    final dark = Paint()..color = const Color(0xFF2F8F43);
    final mid = Paint()..color = const Color(0xFF47AD54);
    final light = Paint()..color = const Color(0xFF74CF6B);
    canvas.drawCircle(b + Offset(-13 * s, -26 * s), 14 * s, dark);
    canvas.drawCircle(b + Offset(13 * s, -26 * s), 14 * s, dark);
    canvas.drawCircle(b + Offset(0, -36 * s), 19 * s, mid);
    canvas.drawCircle(b + Offset(-5 * s, -42 * s), 11 * s, light);
    canvas.drawCircle(b + Offset(-12 * s, -31 * s), 7 * s, light);
  }

  void _flower(Canvas canvas, Offset c, double s, Color col) {
    canvas.drawLine(c, c + Offset(0, 9 * s), Paint()..color = const Color(0xFF2F8F36)..strokeWidth = 1.4 * s);
    final p = Paint()..color = col;
    for (var i = 0; i < 5; i++) {
      final a = i * _tau / 5;
      canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * 3.2 * s, 2.4 * s, p);
    }
    canvas.drawCircle(c, 1.9 * s, Paint()..color = const Color(0xFFFFB300));
  }

  void _butterfly(Canvas canvas, Offset c, double s, double flap, int k) {
    final col = const [Color(0xFFFF6FA5), Color(0xFF7C4DFF), Color(0xFFFF9800)][k];
    final p = Paint()..color = col;
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.drawOval(Rect.fromCenter(center: Offset(-7 * s * flap, -3 * s), width: 13 * s * flap, height: 17 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(7 * s * flap, -3 * s), width: 13 * s * flap, height: 17 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(-5 * s * flap, 6 * s), width: 9 * s * flap, height: 11 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(5 * s * flap, 6 * s), width: 9 * s * flap, height: 11 * s), p);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: 3 * s, height: 16 * s), Radius.circular(2 * s)),
      Paint()..color = const Color(0xFF3E2723),
    );
    canvas.restore();
  }

  void _cloud(Canvas canvas, Offset o, double s) {
    const puffs = [
      [0.0, 0.0, 15.0],
      [20.0, -10.0, 20.0],
      [44.0, -4.0, 17.0],
      [64.0, 3.0, 13.0],
      [30.0, 6.0, 16.0],
    ];
    final shade = Paint()
      ..color = const Color(0x2290B4D8)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 8 * s);
    final body = Paint()
      ..color = Colors.white.withValues(alpha: 0.93)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 2.5 * s);
    final hi = Paint()
      ..color = Colors.white.withValues(alpha: 0.7)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4 * s);
    for (final q in puffs) {
      canvas.drawCircle(o + Offset(q[0] * s, q[1] * s + 8 * s), q[2] * s, shade);
    }
    for (final q in puffs) {
      canvas.drawCircle(o + Offset(q[0] * s, q[1] * s), q[2] * s, body);
    }
    for (final q in puffs) {
      canvas.drawCircle(o + Offset(q[0] * s - 3 * s, q[1] * s - 5 * s), q[2] * s * 0.65, hi);
    }
  }

  @override
  bool shouldRepaint(covariant _WorldPainter old) => true;
}

/// کج‌شدن سه‌بعدی کارت با حرکت ماوس. روی لمس، بدون اثر می‌ماند.
class Tilt3D extends StatefulWidget {
  final Widget child;
  const Tilt3D({super.key, required this.child});

  @override
  State<Tilt3D> createState() => _Tilt3DState();
}

class _Tilt3DState extends State<Tilt3D> {
  Offset _p = Offset.zero;
  bool _hover = false;

  void _onHover(PointerEvent e) {
    final box = context.findRenderObject() as RenderBox?;
    if (box == null || box.size.isEmpty) return;
    setState(() {
      _hover = true;
      _p = Offset(
        (e.localPosition.dx / box.size.width * 2 - 1).clamp(-1.0, 1.0),
        (e.localPosition.dy / box.size.height * 2 - 1).clamp(-1.0, 1.0),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onHover: _onHover,
      onExit: (_) => setState(() {
        _hover = false;
        _p = Offset.zero;
      }),
      child: TweenAnimationBuilder<Offset>(
        tween: Tween<Offset>(end: _p),
        duration: const Duration(milliseconds: 140),
        builder: (context, p, child) {
          final m = Matrix4.identity()
            ..setEntry(3, 2, 0.0012)
            ..rotateX(-p.dy * 0.2)
            ..rotateY(p.dx * 0.2);
          return Transform.translate(
            offset: Offset(0, _hover ? -6 : 0),
            child: Transform(alignment: Alignment.center, transform: m, child: child),
          );
        },
        child: widget.child,
      ),
    );
  }
}
