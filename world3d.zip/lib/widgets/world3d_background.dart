import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'sunny_world_background.dart';

/// کلید بازگشت: false = ظاهر قبلی (آسمان و تپه‌های تخت)، true = دنیای سه‌بعدی.
const bool kWorld3D = true;

/// بر پایهٔ [kWorld3D] یکی از دو پس‌زمینه را نشان می‌دهد.
class WorldBackground extends StatelessWidget {
  final Widget child;
  const WorldBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) =>
      kWorld3D ? World3DBackground(child: child) : SunnyWorldBackground(child: child);
}

/// دنیای سه‌بعدی: لایه‌های عمق‌دار که با حرکت ماوس یا انگشت جابه‌جا می‌شوند.
class World3DBackground extends StatefulWidget {
  final Widget child;
  const World3DBackground({super.key, required this.child});

  @override
  State<World3DBackground> createState() => _World3DBackgroundState();
}

class _World3DBackgroundState extends State<World3DBackground> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 60))..repeat();
  Offset _target = Offset.zero;
  Offset _cur = Offset.zero;

  @override
  void initState() {
    super.initState();
    _c.addListener(() => _cur = Offset.lerp(_cur, _target, 0.07)!);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  void _move(Offset p, Size s) {
    if (s.width <= 0 || s.height <= 0) return;
    _target = Offset((p.dx / s.width * 2 - 1).clamp(-1.0, 1.0), (p.dy / s.height * 2 - 1).clamp(-1.0, 1.0));
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        final size = Size(box.maxWidth, box.maxHeight);
        return Listener(
          behavior: HitTestBehavior.translucent,
          onPointerHover: (e) => _move(e.localPosition, size),
          onPointerMove: (e) => _move(e.localPosition, size),
          child: Stack(
            children: [
              Positioned.fill(
                child: RepaintBoundary(
                  child: CustomPaint(painter: _WorldPainter(_c, () => _cur)),
                ),
              ),
              Positioned.fill(child: widget.child),
            ],
          ),
        );
      },
    );
  }
}

class _WorldPainter extends CustomPainter {
  final Animation<double> anim;
  final Offset Function() tilt;
  _WorldPainter(this.anim, this.tilt) : super(repaint: anim);

  static const double _tau = math.pi * 2;

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    final t = anim.value;
    final tl = tilt();
    final s = (math.min(w, h) / 500).clamp(0.7, 1.4);
    Offset off(double d) => Offset(-tl.dx * d, -tl.dy * d * 0.5);
    void layer(double d, void Function() draw) {
      canvas.save();
      final o = off(d);
      canvas.translate(o.dx, o.dy);
      draw();
      canvas.restore();
    }

    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF2FA8F0), Color(0xFF7FD3FF), Color(0xFFDDF4FF)],
          stops: [0.0, 0.55, 1.0],
        ).createShader(rect),
    );

    // خورشید و پرتوها
    layer(4, () {
      final sun = Offset(w * 0.82, h * 0.13);
      final r = (math.min(w, h) * 0.08).clamp(28.0, 70.0);
      canvas.drawCircle(
        sun,
        r * 3.6,
        Paint()
          ..shader = const RadialGradient(colors: [Color(0xBBFFF3B0), Color(0x00FFF3B0)])
              .createShader(Rect.fromCircle(center: sun, radius: r * 3.6)),
      );
      final ray = Paint()
        ..color = const Color(0x55FFE082)
        ..strokeWidth = r * 0.18
        ..strokeCap = StrokeCap.round;
      for (var i = 0; i < 14; i++) {
        final a = t * _tau + i * _tau / 14;
        canvas.drawLine(sun + Offset(math.cos(a), math.sin(a)) * (r * 1.35), sun + Offset(math.cos(a), math.sin(a)) * (r * 2.1), ray);
      }
      canvas.drawCircle(sun, r, Paint()..color = const Color(0xFFFFD54F));
      canvas.drawCircle(sun, r * 0.72, Paint()..color = const Color(0xFFFFE98A));
    });

    // کوه‌های دور
    layer(8, () => _hill(canvas, w, h, 0.66, 0.045, 0.6, 1.1, const Color(0xFF9ED6C9)));

    // ابرها
    layer(14, () {
      const clouds = [
        [0.10, 0.10, 1.2, 1.0],
        [0.50, 0.20, 0.9, 2.0],
        [0.80, 0.06, 1.0, 1.0],
      ];
      for (final c in clouds) {
        final x = (((c[0] + t * c[3] * 1.3) % 1.3) - 0.15) * w;
        _cloud(canvas, Offset(x, h * c[1]), c[2] * s * 1.2);
      }
    });

    // تپهٔ میانی با درخت
    layer(20, () {
      _hill(canvas, w, h, 0.76, 0.05, 0.2, 1.0, const Color(0xFF86D168));
      for (final f in const [0.08, 0.22, 0.47, 0.66, 0.9]) {
        final x = f * w;
        _tree(canvas, Offset(x, _hillY(x, w, h, 0.76, 0.05, 0.2, 1.0) + 6 * s), s);
      }
    });

    // پروانه‌ها
    layer(30, () {
      for (var k = 0; k < 3; k++) {
        final x = w * (0.2 + 0.3 * k + 0.08 * math.sin(t * _tau * 3 + k));
        final y = h * (0.46 + 0.07 * k) + math.sin(t * _tau * 5 + k * 2) * 18 * s;
        _butterfly(canvas, Offset(x, y), s, 0.35 + 0.65 * math.sin(t * _tau * 120 + k).abs(), k);
      }
    });

    // تپهٔ نزدیک با گل
    layer(36, () {
      _hill(canvas, w, h, 0.88, 0.04, 1.4, 1.2, const Color(0xFF5CBF4A));
      final rnd = math.Random(7);
      const colors = [Color(0xFFFF6FA5), Color(0xFFFFD54F), Colors.white, Color(0xFFFF8A65)];
      for (var i = 0; i < 46; i++) {
        final x = rnd.nextDouble() * w;
        final yy = _hillY(x, w, h, 0.88, 0.04, 1.4, 1.2);
        final y = yy + 8 + rnd.nextDouble() * (h - yy).clamp(0, h * 0.12);
        final sway = math.sin(t * _tau * 4 + i) * 2 * s;
        _flower(canvas, Offset(x + sway, y), s, colors[i % colors.length]);
      }
    });

    // بوتهٔ جلو (سریع‌ترین حرکت)
    layer(52, () {
      final p = Paint()..color = const Color(0xFF3FA53A);
      for (final e in const [[0.02, 1.0], [0.97, 1.1]]) {
        final c = Offset(w * e[0], h * 1.0);
        final r = 46 * s * e[1];
        canvas.drawCircle(c, r, p);
        canvas.drawCircle(c + Offset(-r * 0.7, r * 0.2), r * 0.7, p);
        canvas.drawCircle(c + Offset(r * 0.7, r * 0.2), r * 0.7, p);
      }
    });
  }

  double _hillY(double x, double w, double h, double base, double amp, double phase, double freq) =>
      h * base + math.sin(x / w * _tau * freq + phase) * h * amp;

  void _hill(Canvas canvas, double w, double h, double base, double amp, double phase, double freq, Color color) {
    final path = Path()..moveTo(-90, h + 90);
    for (double x = -90; x <= w + 90; x += 12) {
      path.lineTo(x, _hillY(x, w, h, base, amp, phase, freq));
    }
    path
      ..lineTo(w + 90, h + 90)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  void _tree(Canvas canvas, Offset b, double s) {
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromLTWH(b.dx - 4 * s, b.dy - 20 * s, 8 * s, 22 * s), Radius.circular(3 * s)),
      Paint()..color = const Color(0xFF8D6E4B),
    );
    final g = Paint()..color = const Color(0xFF3E9E4A);
    canvas.drawCircle(b + Offset(0, -34 * s), 17 * s, g);
    canvas.drawCircle(b + Offset(-12 * s, -24 * s), 13 * s, g);
    canvas.drawCircle(b + Offset(12 * s, -24 * s), 13 * s, g);
    canvas.drawCircle(b + Offset(-4 * s, -40 * s), 7 * s, Paint()..color = const Color(0x44FFFFFF));
  }

  void _flower(Canvas canvas, Offset c, double s, Color col) {
    final p = Paint()..color = col;
    for (var i = 0; i < 5; i++) {
      final a = i * _tau / 5;
      canvas.drawCircle(c + Offset(math.cos(a), math.sin(a)) * 4 * s, 3 * s, p);
    }
    canvas.drawCircle(c, 2.4 * s, Paint()..color = const Color(0xFFFFB300));
  }

  void _butterfly(Canvas canvas, Offset c, double s, double flap, int k) {
    final col = const [Color(0xFFFF6FA5), Color(0xFF7C4DFF), Color(0xFFFF9800)][k];
    final p = Paint()..color = col;
    canvas.save();
    canvas.translate(c.dx, c.dy);
    canvas.drawOval(Rect.fromCenter(center: Offset(-7 * s * flap, -3 * s), width: 13 * s * flap, height: 17 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(7 * s * flap, -3 * s), width: 13 * s * flap, height: 17 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(-5 * s * flap, 6 * s), width: 9 * s * flap, height: 11 * s), p);
    canvas.drawOval(Rect.fromCenter(center: Offset(5 * s * flap, 6 * s), width: 9 * s * flap, height: 11 * s), p);
    canvas.drawRRect(
      RRect.fromRectAndRadius(Rect.fromCenter(center: Offset.zero, width: 3 * s, height: 16 * s), Radius.circular(2 * s)),
      Paint()..color = const Color(0xFF3E2723),
    );
    canvas.restore();
  }

  void _cloud(Canvas canvas, Offset o, double s) {
    final p = Paint()..color = Colors.white.withValues(alpha: 0.93);
    canvas.drawCircle(o, 14 * s, p);
    canvas.drawCircle(o + Offset(18 * s, -8 * s), 18 * s, p);
    canvas.drawCircle(o + Offset(40 * s, 0), 14 * s, p);
    canvas.drawRRect(
      RRect.fromLTRBR(o.dx - 14 * s, o.dy - 2 * s, o.dx + 54 * s, o.dy + 14 * s, Radius.circular(14 * s)),
      p,
    );
  }

  @override
  bool shouldRepaint(covariant _WorldPainter old) => true;
}

/// کج‌شدن سه‌بعدی کارت با حرکت ماوس. روی لمس، بدون اثر می‌ماند.
class Tilt3D extends StatefulWidget {
  final Widget child;
  const Tilt3D({super.key, required this.child});

  @override
  State<Tilt3D> createState() => _Tilt3DState();
}

class _Tilt3DState extends State<Tilt3D> {
  Offset _p = Offset.zero;
  bool _hover = false;

  void _onHover(PointerEvent e) {
    final box = context.findRenderObject() as RenderBox?;
    if (box == null || box.size.isEmpty) return;
    setState(() {
      _hover = true;
      _p = Offset(
        (e.localPosition.dx / box.size.width * 2 - 1).clamp(-1.0, 1.0),
        (e.localPosition.dy / box.size.height * 2 - 1).clamp(-1.0, 1.0),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onHover: _onHover,
      onExit: (_) => setState(() {
        _hover = false;
        _p = Offset.zero;
      }),
      child: TweenAnimationBuilder<Offset>(
        tween: Tween<Offset>(end: _p),
        duration: const Duration(milliseconds: 140),
        builder: (context, p, child) {
          final m = Matrix4.identity()
            ..setEntry(3, 2, 0.0012)
            ..rotateX(-p.dy * 0.2)
            ..rotateY(p.dx * 0.2);
          return Transform.translate(
            offset: Offset(0, _hover ? -6 : 0),
            child: Transform(alignment: Alignment.center, transform: m, child: child),
          );
        },
        child: widget.child,
      ),
    );
  }
}
