import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

enum _Act { idle, walk, read, tea, dance, spin }

/// پل بین صفحه و آواتار: لمس یا حرکت ماوس را به آواتار خبر می‌دهد.
class AvatarController {
  void Function(Offset pos, bool down)? _onPing;
  void ping(Offset pos, {bool down = false}) => _onPing?.call(pos, down);
}

/// شخصیت مستقل: خودش راه می‌رود، کتاب می‌خواند، چای می‌نوشد، می‌رقصد و می‌چرخد.
/// گاهی به سمت جایی که لمس یا ماوس بوده می‌آید. پشت محتوای صفحه است، پس هیچ‌وقت روی کارت‌ها نمی‌افتد.
class LivingAvatar extends StatefulWidget {
  final AvatarController controller;
  const LivingAvatar({super.key, required this.controller});

  @override
  State<LivingAvatar> createState() => _LivingAvatarState();
}

class _LivingAvatarState extends State<LivingAvatar> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final ValueNotifier<int> _frame = ValueNotifier<int>(0);
  final math.Random _rnd = math.Random();
  ui.Image? _img;
  Size _size = Size.zero;

  double _x = -1;
  double _tx = 0;
  _Act _act = _Act.idle;
  double _actT = 0;
  double _actDur = 2;
  double _time = 0;
  double _cool = 5;
  double _look = 0;
  double _lookDir = 0;
  double _walkPhase = 0;
  double _facing = 1;
  double _sit = 0;
  double _hair = 0.9;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    widget.controller._onPing = _ping;
    _ticker = createTicker(_tick)..start();
    _load();
  }

  @override
  void dispose() {
    widget.controller._onPing = null;
    _ticker.dispose();
    _frame.dispose();
    _img?.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final data = await rootBundle.load('assets/images/angel.png');
    final codec = await ui.instantiateImageCodec(data.buffer.asUint8List());
    final f = await codec.getNextFrame();
    if (!mounted) return;
    setState(() => _img = f.image);
  }

  double _unit(Size sz) => (sz.height * 0.30).clamp(150.0, 260.0).toDouble();

  void _setAct(_Act a, double dur) {
    _act = a;
    _actT = 0;
    _actDur = dur;
  }

  void _next() {
    final u = _unit(_size);
    final margin = u * 0.45;
    final r = _rnd.nextDouble();
    if (r < 0.30) {
      var t = margin + _rnd.nextDouble() * math.max(1.0, _size.width - 2 * margin);
      if ((t - _x).abs() < 80) t = (_x < _size.width / 2) ? _x + 160 : _x - 160;
      _tx = t.clamp(margin, math.max(margin, _size.width - margin)).toDouble();
      _setAct(_Act.walk, 30);
    } else if (r < 0.50) {
      _setAct(_Act.read, 7 + _rnd.nextDouble() * 4);
    } else if (r < 0.70) {
      _setAct(_Act.tea, 6 + _rnd.nextDouble() * 3);
    } else if (r < 0.88) {
      _setAct(_Act.dance, 5 + _rnd.nextDouble() * 3);
    } else {
      _setAct(_Act.spin, 2.6);
    }
  }

  void _ping(Offset pos, bool down) {
    if (_size.isEmpty || _x < 0 || _cool > 0) return;
    if (_act == _Act.spin || _act == _Act.dance) return;
    if (_rnd.nextDouble() > (down ? 0.35 : 0.006)) return;
    final u = _unit(_size);
    final margin = u * 0.45;
    final side = _x < pos.dx ? -1.0 : 1.0;
    _tx = (pos.dx + side * u * 0.55).clamp(margin, math.max(margin, _size.width - margin)).toDouble();
    _setAct(_Act.walk, 30);
    _cool = 10 + _rnd.nextDouble() * 6;
    _look = 3.5;
    _lookDir = pos.dx > _x ? 1.0 : -1.0;
  }

  void _tick(Duration e) {
    var dt = (e - _last).inMicroseconds / 1e6;
    _last = e;
    if (dt <= 0) return;
    if (dt > 0.05) dt = 0.05;
    _time += dt;
    _actT += dt;
    _cool -= dt;
    if (_look > 0) _look -= dt;
    if (!_size.isEmpty) {
      if (_x < 0) _x = _size.width * 0.25;
      final u = _unit(_size);
      switch (_act) {
        case _Act.idle:
          if (_actT > _actDur) _next();
          break;
        case _Act.walk:
          final d = _tx - _x;
          final step = u * 0.28 * dt;
          if (d.abs() <= step) {
            _x = _tx;
            _setAct(_Act.idle, 1.5 + _rnd.nextDouble() * 2);
          } else {
            _x += d.sign * step;
            _facing = d.sign;
            _walkPhase += dt * 7;
          }
          break;
        default:
          if (_actT > _actDur) _setAct(_Act.idle, 1.5 + _rnd.nextDouble() * 2);
      }
      final sitTarget = (_act == _Act.read || _act == _Act.tea) ? 1.0 : 0.0;
      _sit += (sitTarget - _sit) * math.min(1.0, dt * 4);
      double hairTarget;
      switch (_act) {
        case _Act.walk:
          hairTarget = 1.4;
          break;
        case _Act.dance:
          hairTarget = 2.0;
          break;
        case _Act.spin:
          hairTarget = 2.4;
          break;
        case _Act.read:
        case _Act.tea:
          hairTarget = 0.7;
          break;
        default:
          hairTarget = 0.9;
      }
      _hair += (hairTarget - _hair) * math.min(1.0, dt * 2);
    }
    _frame.value++;
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, box) {
        _size = Size(box.maxWidth, box.maxHeight);
        return IgnorePointer(
          child: RepaintBoundary(
            child: CustomPaint(size: Size.infinite, painter: _AvatarPainter(this)),
          ),
        );
      },
    );
  }
}

double _ease(double x) {
  final c = x.clamp(0.0, 1.0).toDouble();
  return c * c * (3 - 2 * c);
}

Path _star(Offset c, double r) {
  final p = Path();
  for (var i = 0; i < 8; i++) {
    final a = i * math.pi / 4 - math.pi / 2;
    final rr = i.isEven ? r : r * 0.32;
    final pt = c + Offset(math.cos(a), math.sin(a)) * rr;
    if (i == 0) {
      p.moveTo(pt.dx, pt.dy);
    } else {
      p.lineTo(pt.dx, pt.dy);
    }
  }
  p.close();
  return p;
}

class _AvatarPainter extends CustomPainter {
  final _LivingAvatarState s;
  _AvatarPainter(this.s) : super(repaint: s._frame);

  @override
  void paint(Canvas canvas, Size size) {
    final img = s._img;
    if (img == null || s._x < 0) return;
    final iw = img.width.toDouble();
    final ih = img.height.toDouble();
    final u = s._unit(size);
    final scale = u / ih;
    final sw = iw * scale;
    final t = s._time;
    final act = s._act;
    final ground = size.height - 12;
    final cx = s._x;
    final drop = s._sit * u * 0.07;

    // سایهٔ زمین
    canvas.drawOval(
      Rect.fromCenter(center: Offset(cx, ground + 2), width: sw * 0.55, height: u * 0.045),
      Paint()
        ..color = const Color(0x40000000)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
    );

    // حرکت بدن
    var bob = math.sin(t * 2) * 1.5;
    var rot = 0.0;
    var sx = 1.0;
    switch (act) {
      case _Act.walk:
        bob = math.sin(s._walkPhase).abs() * u * 0.03;
        rot = s._facing * 0.03 + math.sin(s._walkPhase) * 0.03;
        break;
      case _Act.dance:
        bob = math.sin(t * 6).abs() * u * 0.05;
        rot = math.sin(t * 3) * 0.1;
        break;
      case _Act.spin:
        sx = math.cos(s._actT / s._actDur * math.pi * 4);
        bob = math.sin(s._actT / s._actDur * math.pi).abs() * u * 0.04;
        break;
      case _Act.read:
      case _Act.tea:
        rot = -0.03 * s._sit;
        break;
      default:
        break;
    }
    if (s._look > 0) rot += s._lookDir * 0.06 * math.min(1.0, s._look);

    canvas.save();
    canvas.translate(cx, ground + drop - bob);
    canvas.rotate(rot);
    canvas.scale(sx, 1.0);

    final paint = Paint()
      ..filterQuality = FilterQuality.medium
      ..isAntiAlias = true;
    final headY = ih * 0.61;
    const n = 48;
    final amp = iw * 0.035 * s._hair;
    for (var i = 0; i < n; i++) {
      final y0 = headY * i / n;
      final y1 = headY * (i + 1) / n;
      final mid = (y0 + y1) / 2;
      final f = math.pow((headY - mid) / headY, 1.3).toDouble();
      final wave = math.sin(t * 1.3 + mid * 0.006) + 0.5 * math.sin(t * 0.7 + mid * 0.011 + 1.3);
      final gust = math.sin(t * 0.4) * 0.4;
      final dx = (wave * 0.8 + gust) * amp * f;
      final h = math.min(y1 - y0 + 1.5, ih - y0);
      canvas.drawImageRect(
        img,
        Rect.fromLTWH(0, y0, iw, h),
        Rect.fromLTWH(-sw / 2 + dx * scale, -u + y0 * scale, sw, h * scale),
        paint,
      );
    }
    canvas.drawImageRect(
      img,
      Rect.fromLTWH(0, headY, iw, ih - headY),
      Rect.fromLTWH(-sw / 2, -u + headY * scale, sw, (ih - headY) * scale),
      paint,
    );

    // وسایل
    if (act == _Act.read) _book(canvas, u, t);
    if (act == _Act.tea) _cup(canvas, u, t);
    if (act == _Act.dance || act == _Act.spin) _sparkles(canvas, u, t);
    canvas.restore();

    // پوف زیر پا (وقتی می‌نشیند)
    if (s._sit > 0.02) {
      final k = s._sit;
      final r = RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, ground - u * 0.02), width: u * 0.46, height: u * 0.13 * k),
        Radius.circular(u * 0.06),
      );
      canvas.drawRRect(r, Paint()..color = const Color(0xFFFFA94D));
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset(cx - u * 0.04, ground - u * 0.045), width: u * 0.3, height: u * 0.03 * k),
          Radius.circular(u * 0.02),
        ),
        Paint()..color = const Color(0x55FFFFFF),
      );
    }
  }

  void _book(Canvas canvas, double u, double t) {
    final cx = 0.0;
    final cy = -0.15 * u + math.sin(t * 2) * 0.004 * u;
    final hw = 0.17 * u;
    final hh = 0.11 * u;
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromCenter(center: Offset(cx, cy + 0.012 * u), width: hw * 2 + 0.025 * u, height: hh * 2 + 0.025 * u),
        Radius.circular(0.02 * u),
      ),
      Paint()..color = const Color(0xFF3F6FB5),
    );
    final page = Paint()..color = const Color(0xFFFFFDF7);
    final left = Path()
      ..moveTo(cx, cy - hh)
      ..lineTo(cx - hw, cy - hh * 0.9)
      ..lineTo(cx - hw, cy + hh)
      ..lineTo(cx, cy + hh * 0.9)
      ..close();
    final right = Path()
      ..moveTo(cx, cy - hh)
      ..lineTo(cx + hw, cy - hh * 0.9)
      ..lineTo(cx + hw, cy + hh)
      ..lineTo(cx, cy + hh * 0.9)
      ..close();
    canvas.drawPath(left, page);
    canvas.drawPath(right, page);
    final line = Paint()
      ..color = const Color(0x33607D8B)
      ..strokeWidth = 0.004 * u;
    for (var i = 0; i < 5; i++) {
      final yy = cy - hh * 0.6 + i * hh * 0.35;
      canvas.drawLine(Offset(cx - hw * 0.85, yy), Offset(cx - hw * 0.12, yy), line);
      canvas.drawLine(Offset(cx + hw * 0.12, yy), Offset(cx + hw * 0.85, yy), line);
    }
    final q = (t % 3.4) / 3.4;
    if (q < 0.3) {
      final w = hw * math.cos(q / 0.3 * math.pi);
      final flip = Path()
        ..moveTo(cx, cy - hh)
        ..lineTo(cx + w, cy - hh * 0.9)
        ..lineTo(cx + w, cy + hh)
        ..lineTo(cx, cy + hh * 0.9)
        ..close();
      canvas.drawPath(flip, Paint()..color = const Color(0xFFF1ECE0));
    }
    canvas.drawLine(Offset(cx, cy - hh), Offset(cx, cy + hh * 0.9), Paint()..color = const Color(0x55000000)..strokeWidth = 0.006 * u);
  }

  void _cup(Canvas canvas, double u, double t) {
    final q = (t % 4.0) / 4.0;
    double sip;
    if (q < 0.3) {
      sip = 0;
    } else if (q < 0.5) {
      sip = _ease((q - 0.3) / 0.2);
    } else if (q < 0.7) {
      sip = 1;
    } else if (q < 0.9) {
      sip = _ease(1 - (q - 0.7) / 0.2);
    } else {
      sip = 0;
    }
    final pos = Offset.lerp(Offset(0.11 * u, -0.14 * u), Offset(0.035 * u, -0.27 * u), sip)!;
    final w = 0.06 * u;
    final h = 0.055 * u;
    final body = RRect.fromLTRBAndCorners(
      pos.dx - w / 2,
      pos.dy - h / 2,
      pos.dx + w / 2,
      pos.dy + h / 2,
      bottomLeft: Radius.circular(0.025 * u),
      bottomRight: Radius.circular(0.025 * u),
    );
    canvas.drawArc(
      Rect.fromCenter(center: pos + Offset(0.033 * u, 0), width: 0.03 * u, height: 0.035 * u),
      -math.pi / 2,
      math.pi,
      false,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.007 * u
        ..color = Colors.white,
    );
    canvas.drawRRect(body, Paint()..color = Colors.white);
    canvas.drawRect(
      Rect.fromLTWH(pos.dx - w / 2, pos.dy - 0.005 * u, w, 0.012 * u),
      Paint()..color = const Color(0xFF64B5F6),
    );
    for (var k = 0; k < 3; k++) {
      final base = pos + Offset((k - 1) * 0.016 * u, -0.03 * u);
      final path = Path()..moveTo(base.dx, base.dy);
      for (var j = 1; j <= 6; j++) {
        final x = math.sin(t * 2 + k * 1.7 + j * 0.9) * 0.008 * u * j / 3;
        path.lineTo(base.dx + x, base.dy - j * 0.012 * u);
      }
      canvas.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 0.006 * u
          ..color = Colors.white.withValues(alpha: 0.45),
      );
    }
  }

  void _sparkles(Canvas canvas, double u, double t) {
    for (var k = 0; k < 5; k++) {
      final a = t * 1.5 + k * math.pi * 2 / 5;
      final r = 0.42 * u * (0.75 + 0.25 * math.sin(t * 2 + k));
      final c = Offset(math.cos(a) * r * 0.9, -0.5 * u + math.sin(a) * r * 0.6);
      final alpha = 0.55 + 0.4 * math.sin(t * 4 + k);
      canvas.drawPath(
        _star(c, 0.035 * u * (0.7 + 0.3 * math.sin(t * 3 + k))),
        Paint()..color = const Color(0xFFFFD54F).withValues(alpha: alpha.clamp(0.0, 1.0).toDouble()),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _AvatarPainter old) => true;
}
