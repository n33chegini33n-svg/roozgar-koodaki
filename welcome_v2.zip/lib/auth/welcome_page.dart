import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../theme/app_colors.dart';
import '../widgets/safe_image.dart';
import 'auth_types.dart';
import 'otp_page.dart';

/// تبدیل ارقام فارسی و عربی به انگلیسی
String normalizeDigits(String input) {
  const fa = '۰۱۲۳۴۵۶۷۸۹';
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var out = input;
  for (var i = 0; i < 10; i++) {
    out = out.replaceAll(fa[i], '$i').replaceAll(ar[i], '$i');
  }
  return out;
}

/// صفحهٔ خوش‌آمدگویی + وارد کردن شمارهٔ موبایل
class WelcomePage extends StatefulWidget {
  /// ورود: شمارهٔ همراه و کد را بررسی می‌کند و صفحهٔ اصلی نقش را برمی‌گرداند
  final AuthCallback authenticate;

  const WelcomePage({super.key, required this.authenticate});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  final TextEditingController _phoneController = TextEditingController();
  String? _error;

  // نسبت عکس زمینه (۱۹۲۰ در ۱۶۱۴) و جای خورشید در آن
  static const double _bgRatio = 1920 / 1614;
  // فاصلهٔ مرکز خورشید از بالای عکس، و جایی از عکس که لبهٔ بالای کادر سفید روی آن می‌افتد
  static const double _cardEdgeInImage = 0.654;

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  void _submit() {
    final phone = normalizeDigits(_phoneController.text.trim());
    final valid = RegExp(r'^09\d{9}$').hasMatch(phone);
    if (!valid) {
      setState(() => _error = 'شمارهٔ موبایل را مثل 09123456789 وارد کنید');
      return;
    }
    setState(() => _error = null);
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OtpPage(
          phone: phone,
          authenticate: widget.authenticate,
        ),
      ),
    );
  }

  /// عکس زمینه: یک‌سوم پایین خورشید زیر کادر سفید می‌رود
  Widget _background(double areaW, double areaH) {
    final ih = math.max(areaW / _bgRatio, areaH * 1.6);
    final iw = ih * _bgRatio;
    final top = areaH - _cardEdgeInImage * ih;
    return Stack(
      clipBehavior: Clip.none,
      children: [
        Positioned(
          left: (areaW - iw) / 2,
          top: top,
          width: iw,
          height: ih,
          child: const SafeAssetImage('welcome_bg.jpg', fit: BoxFit.fill),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final keyboard = MediaQuery.of(context).viewInsets.bottom;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: AppColors.sky,
      body: Padding(
        padding: EdgeInsets.only(bottom: keyboard),
        child: Column(
          children: [
            Expanded(
              child: LayoutBuilder(
                builder: (context, box) => _background(box.maxWidth, box.maxHeight),
              ),
            ),
            Container(
              width: double.infinity,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
                boxShadow: [
                  BoxShadow(color: Color(0x33000000), blurRadius: 16, offset: Offset(0, -4)),
                ],
              ),
              child: SafeArea(
                top: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(24, 28, 24, 24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'با هم می‌درخشیم',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.navy),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        'شمارهٔ موبایلی که مدرسه برای شما ثبت کرده را وارد کنید',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 14, color: AppColors.textGrey),
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.center,
                        maxLength: 11,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp(r'[0-9۰-۹٠-٩]')),
                        ],
                        style: const TextStyle(fontSize: 20, letterSpacing: 2),
                        decoration: InputDecoration(
                          counterText: '',
                          hintText: '09123456789',
                          errorText: _error,
                          prefixIcon: const Icon(Icons.phone_android_rounded, color: AppColors.navy),
                          filled: true,
                          fillColor: AppColors.sky.withValues(alpha: 0.5),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                        ),
                        onSubmitted: (_) => _submit(),
                      ),
                      const SizedBox(height: 16),
                      SizedBox(
                        width: double.infinity,
                        height: 52,
                        child: ElevatedButton(
                          onPressed: _submit,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.navy,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                          ),
                          child: const Text('ادامه', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
