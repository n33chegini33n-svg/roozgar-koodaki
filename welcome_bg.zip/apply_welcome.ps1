$f='lib\auth\welcome_page.dart'
$t=[IO.File]::ReadAllText($f)
if(-not $t.Contains("'logo.jpg'")){ "NOT FOUND logo.jpg"; exit }
$t=$t.Replace("'logo.jpg'","'welcome_bg.jpg'").Replace("alignment: Alignment.topCenter,","alignment: Alignment.center,")
[IO.File]::WriteAllText($f,$t)
"ok"
